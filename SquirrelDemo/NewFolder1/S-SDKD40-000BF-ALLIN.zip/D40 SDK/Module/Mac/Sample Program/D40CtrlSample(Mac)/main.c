//================================================================================================
// Copyright Nikon Corporation - All rights reserved
//
// View this file in a non-proportional font, tabs = 3
//================================================================================================

#include	<stdlib.h>
#include	<stdio.h>
#include	"maid3.h"
#include	"maid3d1.h"
#include	"CtrlSample.h"

LPMAIDEntryPointProc	g_pMAIDEntryPoint = NULL;
UCHAR	g_bFileRemoved = false;
#ifdef _WINDOWS
	HINSTANCE	g_hInstModule = NULL;
#else
	CFragConnectionID	g_ConnID = 0;
	short	g_nModRefNum = -1;
#endif

//------------------------------------------------------------------------------------------------------------------------------------
//
int main()
{
#ifdef _WINDOWS
	char	ModulePath[MAX_PATH];
#else
	FSSpec ModulePath;
#endif
	LPRefObj	pRefMod = NULL, pRefSrc = NULL, RefItm = NULL, pRefDat = NULL;
	char	buf[256];
	ULONG	ulModID = 0, ulSrcID = 0;
	UWORD	wSel;
	BOOL	bRet;

	// Search for a Module-file like "D40_Mod.md3".
#ifdef _WINDOWS
	bRet = Search_Module( ModulePath );
#else
	bRet = Search_Module( &ModulePath );
#endif
	if ( bRet == false ) {
		puts( "\"D40 Module\" is not found.\n" );
		return -1;
	}

	// Load the Module-file.
#ifdef _WINDOWS
	bRet = Load_Module( ModulePath );
#else
	bRet = Load_Module( &ModulePath );
#endif
	if ( bRet == false ) {
		puts( "Failed in loading \"D40 Module\".\n" );
		return -1;
	}

	// Allocate memory for reference to Module object.
	pRefMod = (LPRefObj)malloc(sizeof(RefObj));
	if ( pRefMod == NULL ) {
		puts( "There is not enough memory." );
		return -1;
	}
	InitRefObj( pRefMod );

	// Allocate memory for Module object.
	pRefMod->pObject = (LPNkMAIDObject)malloc(sizeof(NkMAIDObject));
	if ( pRefMod->pObject == NULL ) {
		puts( "There is not enough memory." );
		if ( pRefMod != NULL )	free( pRefMod );
		return -1;
	}

	//	Open Module object
	pRefMod->pObject->refClient = (NKREF)pRefMod;
	bRet = Command_Open(	NULL,					// When Module_Object will be opend, "pParentObj" is "NULL".
								pRefMod->pObject,	// Pointer to Module_Object 
								ulModID );			// Module object ID set by Client
	if ( bRet == false ) {
		puts( "Module object can't be opened.\n" );
		if ( pRefMod->pObject != NULL )	free( pRefMod->pObject );
		if ( pRefMod != NULL )	free( pRefMod );
		return -1;
	}

	//	Enumerate Capabilities that the Module has.
	bRet = EnumCapabilities( pRefMod->pObject, &(pRefMod->ulCapCount), &(pRefMod->pCapArray), NULL, NULL );
	if ( bRet == false ) {
		puts( "Failed in enumeration of capabilities." );
		if ( pRefMod->pObject != NULL )	free( pRefMod->pObject );
		if ( pRefMod != NULL )	free( pRefMod );
		return -1;
	}

	//	Set the callback functions(ProgressProc, EventProc and UIRequestProc).
	bRet = SetProc( pRefMod );
	if ( bRet == false ) {
		puts( "Failed in setting a call back function." );
		if ( pRefMod->pObject != NULL )	free( pRefMod->pObject );
		if ( pRefMod != NULL )	free( pRefMod );
		return -1;
	}

	// Module Command Loop
	do {
		printf( "\nSelect (1-6, 0)\n" );
		printf( " 1. Select Device            2. AsyncRate                3. IsAlive\n" );
		printf( " 4. Name                     5. ModuleType               6. Version\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// Children[3.7]
				// Select Device
				bRet = SelectSource( pRefMod, &ulSrcID );
				if ( bRet == false ) break;
				if( ulSrcID > 0 )
					bRet = SourceCommandLoop( pRefMod, ulSrcID );
				break;
			case 2:// AsyncRate[9.1]
				bRet = SetUnsignedCapability( pRefMod, kNkMAIDCapability_AsyncRate );
				break;
			case 3:// IsAlive[9.6]
				bRet = SetBoolCapability( pRefMod, kNkMAIDCapability_IsAlive );
				break;
			case 4:// Name[9.9]
				bRet = SetStringCapability( pRefMod, kNkMAIDCapability_Name );
				break;
			case 5:// ModuleType[9.53]
				bRet = SetUnsignedCapability( pRefMod, kNkMAIDCapability_ModuleType );
				break;
			case 6:// Version[9.57]
				bRet = SetUnsignedCapability( pRefMod, kNkMAIDCapability_Version );
				break;
			default:
				wSel = 0;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel > 0 && bRet == true );

	// Close Module_Object
	bRet = Close_Module( pRefMod );
	if ( bRet == false )
		puts( "Module object can not be closed.\n" );

	// Unload Module
#ifdef _WINDOWS
	FreeLibrary( g_hInstModule );
	g_hInstModule = NULL;
#else
	CloseConnection( &g_ConnID );
	g_ConnID = 0;
	g_nModRefNum = -1;
#endif

	// Free memory blocks allocated in this function.
	if ( pRefMod->pObject != NULL )	free( pRefMod->pObject );
	if ( pRefMod != NULL )	free( pRefMod );
	
	puts( "This sample program has terminated.\n" );
	return 0;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL SourceCommandLoop( LPRefObj pRefMod, ULONG ulSrcID )
{
	LPRefObj	pRefSrc = NULL;
	char	buf[256];
	ULONG	ulItemID = 0;
	UWORD	wSel;
	BOOL	bRet = true;

	pRefSrc = GetRefChildPtr_ID( pRefMod, ulSrcID );
	if ( pRefSrc == NULL ) {
		// Create Source object and RefSrc structure.
		if ( AddChild( pRefMod, ulSrcID ) == true ) {
			printf("Source object is opened.\n");
		} else {
			printf("Source object can't be opened.\n");
			return false;
		}
		pRefSrc = GetRefChildPtr_ID( pRefMod, ulSrcID );
	}

	// command loop
	do {
		printf( "\nSelect (1-10, 0)\n" );
		printf( " 1. Select Item Object       2. Camera settings(1)       3. Camera settings(2)\n" );
		printf( " 4. Camera settings(3)       5. Custom Menu              6. Async\n" );
		printf( " 7. Autofocus                8. Capture                  9. AFCapture\n" );
		printf( "10. PreCapture\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// Children[3.7]
				// Select Item  Object
				ulItemID = 0;
				bRet = SelectItem( pRefSrc, &ulItemID );
				if( bRet == true && ulItemID > 0 )
					bRet = ItemCommandLoop( pRefSrc, ulItemID );
				break;
			case 2:// Camera setting 1
				bRet = SetUpCamera1( pRefSrc );
				break;
			case 3:// Camera setting 2
				bRet = SetUpCamera2( pRefSrc );
				break;
			case 4:// Camera setting 3
				bRet = SetUpCamera3( pRefSrc );
				break;
			case 5:// CustomSetting Menu
				bRet = SetCustomSettings( pRefSrc );
				break;
			case 6:// Async[8.1]
				bRet = Command_Async( pRefMod->pObject );
				break;
			case 7:// AutoFocus[3.27]
				bRet = IssueProcess( pRefSrc, kNkMAIDCapability_AutoFocus );
				break;
			case 8:// Capture[3.17]
				bRet = IssueProcess( pRefSrc, kNkMAIDCapability_Capture );
				Command_Async( pRefSrc->pObject );
				break;
			case 9:// AFCapture[2.77]
				bRet = IssueProcess( pRefSrc, kNkMAIDCapability_AFCapture );
				Command_Async( pRefSrc->pObject );
				break;
			case 10:// PreCapture[2.76]
				bRet = IssueProcess( pRefSrc, kNkMAIDCapability_PreCapture );
				break;
			default:
				wSel = 0;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
		WaitEvent();
	} while( wSel > 0 );

// Close Source_Object
	bRet = RemoveChild( pRefMod, ulSrcID );

	return true;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL SetUpCamera1( LPRefObj pRefSrc ) 
{
	char	buf[256], filename[256];
	UWORD	wSel, wSubSel;
	BOOL	bRet = true;
	ULONG	ulLutIndex = 0;


	do {
		// Wait for selection by user
		printf( "\nSelect the item you want to set up\n" );
		printf( " 1. IsAlive                 2. Name                 3. Interface\n" );
		printf( " 4. DataTypes               5. Lut                  6. LutHeader\n" );
		printf( " 7. FlashMode               8. InternalFlashStatus  9. InternalFlashComp\n" );
		printf( "10. LockFocus              11. LockExposure        12. ExposureStatus\n" );
		printf( "13. ExposureMode           14. ShutterSpeed        15. Aperture\n" );
		printf( "16. FlexibleProgram        17. ExposureComp        18. FocusMode\n" );
		printf( "19. FocusPreferredArea     20. FocalLength         21. RemainContinuousShooting\n" );
		printf( "22. ContinuousShootingNum\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// IsAlive[3.6]
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_IsAlive );
				break;
			case 2:// Name[3.9]
				bRet = SetStringCapability( pRefSrc, kNkMAIDCapability_Name );
				break;
			case 3:// Interface[3.11]
				bRet = SetStringCapability( pRefSrc, kNkMAIDCapability_Interface );
				break;
			case 4:// DataTypes[3.12]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_DataTypes );
				break;
			case 5:// Lut[3.37]
				strcpy( filename, "D40Lut.dat" );
				// sub command loop
				do {
					printf( "\nSelect (1-3, 0)\n" );
					printf( " 1. Load LUT from the file named \"D40Lut.dat\"\n" );
					printf( " 2. Save LUT in the file named \"D40Lut.dat\"\n" );
					printf( " 3. Make LUT from gamma\n" );
					printf( " 0. Exit\n>" );
					scanf( "%s", buf );
					wSubSel = atoi( buf );

					// Lut save or load
					switch( wSubSel )
					{
						case 1:
							bRet = LoadArrayCapability( pRefSrc, kNkMAIDCapability_Lut, filename );
							break;
						case 2:
							bRet = SaveArrayCapability( pRefSrc, kNkMAIDCapability_Lut, filename );
							break;
						case 3:
							bRet = SetNewLut( pRefSrc );
							break;
						default:
							wSubSel = 0;
					}
					if ( bRet == false )	return false;
				} while( wSubSel > 0 );
				break;
			case 6:// LutHeader[2.79]
				strcpy( filename, "LHeader.dat" );
				// sub command loop
				do {
					printf( "\nSelect (1-3, 0)\n" );
					printf( " 1. Load LUT Header from the file named \"LHeader.dat\"\n" );
					printf( " 2. Save LUT Header in the file named \"LHeader.dat\"\n" );
					printf( " 3. Show LUT Header \n" );
					printf( " 0. Exit\n>" );
					scanf( "%s", buf );
					wSubSel = atoi( buf );

					// LutHeader save or load
					switch( wSubSel )
					{
						case 1:
							bRet = LoadArrayCapability( pRefSrc, kNkMAIDCapability_LutHeader, filename );
							break;
						case 2:
							bRet = SaveArrayCapability( pRefSrc, kNkMAIDCapability_LutHeader, filename );
							break;
						case 3:
							bRet = ShowArrayCapability( pRefSrc, kNkMAIDCapability_LutHeader );
							break;
						default:
							wSubSel = 0;
					}
					if ( bRet == false )	return false;
				} while( wSubSel > 0 );
				break;
			case 7:// FlashMode[3.52]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_FlashMode );
				break;
			case 8:// InternalFlashStatus[2.75]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_InternalFlashStatus );
				break;
			case 9:// InternalFlashComp[2.27]
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_InternalFlashComp );
				break;
			case 10:// LockFocus[2.63]
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_LockFocus );
				break;
			case 11:// LockExposure[2.64]
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_LockExposure );
				break;
			case 12:// ExposureStatus[2.68]
				bRet = SetFloatCapability( pRefSrc, kNkMAIDCapability_ExposureStatus );
				break;
			case 13:// ExposureMode[2.51]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_ExposureMode );
				break;
			case 14:// ShutterSpeed[2.52]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_ShutterSpeed );
				break;
			case 15:// Aperture(F Number)[2.53]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_Aperture );
				break;
			case 16:// FlexibleProgram[2.55]
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_FlexibleProgram );
				break;
			case 17:// ExposureComp[2.54]
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_ExposureComp );
				break;
			case 18:// FocusMode[2.61]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_FocusMode );
				break;
			case 19:// FocusPreferredArea[2.56]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_FocusPreferredArea );
				break;
			case 20:// FocalLength[2.62]
				bRet = SetFloatCapability( pRefSrc, kNkMAIDCapability_FocalLength );
				break;
			case 21:// RemainContinuousShooting[2.66]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_RemainContinuousShooting );
				break;
			case 22:// ContinuousShootingNum[2.65]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_ContinuousShootingNum );
				break;
			default:
				wSel = 0;
				break;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel != 0 );

	return bRet;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL SetUpCamera2( LPRefObj pRefSrc ) 
{
	char	buf[256];
	UWORD	wSel;
	BOOL bRet = true;

	do {
		// Wait for selection by user
		printf( "\nSelect the item you want to set up\n" );
		printf( " 1. LockCamera           2. LensInfo                   3. UserComment\n" );
		printf( " 4. EnableComment        5. ClockDateTime              6. ResetFileNumber\n" );
		printf( " 7. NumberingMode        8. BatteryLevel               9. CameraInclinationMode\n" );
		printf( "10. CameraInclination\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// LockCamera[2.82]
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_LockCamera );
				break;
			case 2:// LensInfo[2.70]
				bRet = SetStringCapability( pRefSrc, kNkMAIDCapability_LensInfo );
				break;
			case 3:// UserComment[2.45]
				bRet = SetStringCapability( pRefSrc, kNkMAIDCapability_UserComment );
				break;
			case 4:// EnableComment[2.46]
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_EnableComment );
				break;
			case 5:// ClockDateTime[2.50]
				bRet = SetDateTimeCapability( pRefSrc, kNkMAIDCapability_ClockDateTime );
				break;
			case 6:// ResetFileNumber[2.48]
				bRet = IssueProcess( pRefSrc, kNkMAIDCapability_ResetFileNumber );
				break;
			case 7:// NumberingMode[2.47]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_NumberingMode );
				break;
			case 8:// BatteryLevel[3.48]
				bRet = SetIntegerCapability( pRefSrc, kNkMAIDCapability_BatteryLevel );
				break;
			case 9:// CameraInclinationMode[2.49]
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_CameraInclinationMode );
				break;
			case 10:// CameraInclination[2.67]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_CameraInclination );
				break;
			default:
				wSel = 0;
				break;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel != 0 );

	return bRet;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL SetUpCamera3( LPRefObj pRefSrc ) 
{
	char	buf[256], filename[256];
	UWORD	wSel, wSubSel;
	NkMAIDWBPresetData stPresetData;
	BOOL bRet = true;

	do {
		// Wait for selection by user
		printf( "\nSelect the item you want to set up\n" );
		printf( " 1. CompressionLevel         2. ImageSize           3. WBMode\n" );
		printf( " 4. Sensitivity              5. ImageSetting        6. ColorReproduct\n" );
		printf( " 7. SaturationSetting        8. ColorAdjustment     9. WBTuneAuto\n" );
		printf( "10. WBTuneIncandescent      11. WBTuneFluorescent  12. WBTuneSunny\n" );
		printf( "13. WBTuneFlash             14. WBTuneShade        15. WBTuneCloudy\n" );
		printf( "16. WBPresetData            17. NoiseReduction\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// Compression Level[2.7]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_CompressionLevel );
				break;
			case 2:// ImageSize[2.8]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_ImageSize );
				break;
			case 3:// WBMode[2.9]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_WBMode );
				break;
			case 4:// Sensitivity[2.17]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_Sensitivity );
				break;
			case 5:// ImageSetting[2.1]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_ImageSetting );
				break;
			case 6:// ColorReproduct[2.4]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_ColorReproduct );
				break;
			case 7:// SaturationSetting[2.5]
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_SaturationSetting );
				break;
			case 8:// ColorAdjustment[2.6]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_ColorAdjustment );
				break;
			case 9:// WBTuneAuto[2.10]
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_WBTuneAuto );
				break;
			case 10:// WBTuneIncandescent[2.11]
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_WBTuneIncandescent );
				break;
			case 11:// WBTuneFluorescent[2.12]
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_WBTuneFluorescent );
				break;
			case 12:// WBTuneSunny[2.13] 
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_WBTuneSunny );
				break;
			case 13:// WBTuneFlash[2.14]
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_WBTuneFlash );
				break;
			case 14:// WBTuneShade[2.15] 
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_WBTuneShade );
				break;
			case 15:// WBTuneCloudy[2.16] 
				bRet = SetRangeCapability( pRefSrc, kNkMAIDCapability_WBTuneCloudy );
				break;
			case 16:// WBPresetData[2.60] 
				strcpy( filename, "PresetData.jpg" );
				// sub command loop
				do {
					memset( &stPresetData, 0, sizeof(NkMAIDWBPresetData) );

					printf( "\nSelect (1, 0)\n" );
					printf( " 1. Set WB Preset data the file named \"PresetData.jpg\"\n" );
					printf( " 0. Exit\n>" );
					scanf( "%s", buf );
					wSubSel = atoi( buf );
					switch( wSubSel )
					{
						case 1://Set WB Preset data
						{
							printf( "\nSet preset gain value by decimal, or Exit(0).\n>" );
							scanf( "%s", buf );
							stPresetData.ulPresetGain = atoi( buf );
							if (stPresetData.ulPresetGain == 0) break;
							bRet = SetWBPresetDataCapability( pRefSrc, &stPresetData, filename );
							break;
						default:
							wSubSel = 0;
						}
					}
					if ( bRet == false )	return false;
				} while( wSubSel > 0 );
				break;
			case 17:// NoiseReduction[2.18]
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_NoiseReduction );
				break;

			default:
				wSel = 0;
				break;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel != 0 );

	return bRet;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL SetCustomSettings( LPRefObj pRefSrc ) 
{
	char	buf[256];
	UWORD	wSel;
	BOOL bRet = true;

	do {
		// Wait for selection by user
		printf( "\nSelect a Custom Setting\n" );
		printf( " 1. ResetCustomSetting       2. ShootNoCard        3. IsoControl \n" );
		printf( " 4. LimitImageDisplay        5. AutoOffDelay       6. SelfTimerDuration\n" );
		printf( " 7. AEAFLockButton           8. AELockonRelease    9. MeteringMode\n" );
		printf( "10. ShootingMode            11. EdgeEnhancement    12. Curve\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// ResetCustomSetting[2.19] 
				bRet = IssueProcess( pRefSrc, kNkMAIDCapability_ResetCustomSetting );
				break;
			case 2:// ShootNoCard[2.25]
				SetBoolCapability( pRefSrc, kNkMAIDCapability_ShootNoCard );
				break;
			case 3:// IsoControl[2.29] 
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_IsoControl );
				break;
			case 4:// LimitImageDisplay[2.40] 
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_LimitImageDisplay );
				break;
			case 5:// AutoOffDelay[2.42] 
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_AutoOffDelay );
				break;
			case 6:// SelfTimerDuration[2.43] 
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_SelfTimerDuration );
				break;
			case 7:// AEAFLockButton[2.33]
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_AEAFLockButton );
				break;
			case 8:// AELockonRelease[2.34] 
				bRet = SetBoolCapability( pRefSrc, kNkMAIDCapability_AELockonRelease );
				break;
			case 9:// MeteringMode[2.24] 
				bRet = SetUnsignedCapability( pRefSrc, kNkMAIDCapability_MeteringMode );
				break;
			case 10:// ShootingMode[2.23] 
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_ShootingMode );
				break;
			case 11:// EdgeEnhancement[2.2] 
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_EdgeEnhancement );
				break;
			case 12:// Curve[2.3] 
				bRet = SetEnumCapability( pRefSrc, kNkMAIDCapability_Curve );
				break;
			default:
				wSel = 0;
				break;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel != 0 );

	return bRet;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL ItemCommandLoop( LPRefObj pRefSrc, ULONG ulItmID )
{
	ULONG	ulDataID = 0;
	LPRefObj	pRefItm = NULL;
	char	buf[256];
	UWORD	wSel;
	BOOL	bRet = true;

	pRefItm = GetRefChildPtr_ID( pRefSrc, ulItmID );
	if ( pRefItm == NULL ) {
		// Create Item object and RefSrc structure.
		if ( AddChild( pRefSrc, ulItmID ) == true ) {
			printf("Item object is opened.\n");
		} else {
			printf("Item object can't be opened.\n");
			return false;
		}
		pRefItm = GetRefChildPtr_ID( pRefSrc, ulItmID );
	}

	// command loop
	do {
		printf( "\nSelect (1-6, 0)\n" );
		printf( " 1. Select Data Object       2. IsAlive                  3. Name\n" );
		printf( " 4. DataTypes                5. DateTime                 6. StoredBytes\n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// Show Children[3.7)
				// Select Data Object
				ulDataID = 0;
				bRet = SelectData( pRefItm, &ulDataID );
				if ( bRet == false )	return false;
				if ( ulDataID == kNkMAIDDataObjType_Image ) {
					// reset file removed flag
					g_bFileRemoved = false;
					bRet = ImageCommandLoop( pRefItm, ulDataID );
					// If the image data was stored in DRAM, the item has been removed.
					if ( g_bFileRemoved ) {
						RemoveChild( pRefSrc, ulItmID );
						pRefItm = NULL;
					}
				} else if ( ulDataID == kNkMAIDDataObjType_Thumbnail )
					bRet = ThumbnailCommandLoop( pRefItm, ulDataID );
				if ( bRet == false )	return false;
				break;
			case 2:// IsAlive[3.6]
				bRet = SetBoolCapability( pRefItm, kNkMAIDCapability_IsAlive );
				break;
			case 3:// Name[3.9]
				bRet = SetStringCapability( pRefItm, kNkMAIDCapability_Name );
				break;
			case 4:// DataTypes[3.12]
				bRet = SetUnsignedCapability( pRefItm, kNkMAIDCapability_DataTypes );
				break;
			case 5:// DateTime[3.13]
				bRet = SetDateTimeCapability( pRefItm, kNkMAIDCapability_DateTime );
				break;
			case 6:// StoredBytes[3.14]
				bRet = SetUnsignedCapability( pRefItm, kNkMAIDCapability_StoredBytes );
				break;
			default:
				wSel = 0;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel > 0 && pRefItm != NULL );

	if ( pRefItm != NULL ) {
		// If the item object remains, close it and remove from parent link.
		bRet = RemoveChild( pRefSrc, ulItmID );
	}

	return bRet;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL ImageCommandLoop( LPRefObj pRefItm, ULONG ulDatID )
{
	LPRefObj	pRefDat = NULL;
	char	buf[256], filename[256];
	UWORD	wSel, wSubSel;
	BOOL	bRet = true;

	pRefDat = GetRefChildPtr_ID( pRefItm, ulDatID );
	if ( pRefDat == NULL ) {
		// Create Image object and RefSrc structure.
		if ( AddChild( pRefItm, ulDatID ) == true ) {
			printf("Image object is opened.\n");
		} else {
			printf("Image object can't be opened.\n");
			return false;
		}
		pRefDat = GetRefChildPtr_ID( pRefItm, ulDatID );
	}

	// command loop
	do {
		printf( "\nSelect (1-7, 0)\n" );
		printf( " 1. IsAlive                  2. Name                     3. StoredBytes\n" );
		printf( " 4. Pixels                   5. RawJpegImageStatus       6. FileHeader\n" );
		printf( " 7. Acquire\n>" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// IsAlive[3.6]
				bRet = SetBoolCapability( pRefDat, kNkMAIDCapability_IsAlive );
				break;
			case 2:// Name[3.9]
				bRet = SetStringCapability( pRefDat, kNkMAIDCapability_Name );
				break;
			case 3:// StoredBytes[3.14]
				bRet = SetUnsignedCapability( pRefDat, kNkMAIDCapability_StoredBytes );
				break;
			case 4:// Show Pixels[3.40]
				// Get to know how many pixels there are in this image.
				bRet = SetSizeCapability( pRefDat, kNkMAIDCapability_Pixels );
				break;
			case 5:// RawJpegImageStatus[2.81]
				bRet = SetUnsignedCapability( pRefDat, kNkMAIDCapability_RawJpegImageStatus );
				break;
			case 6:// FileHeader[2.80]
				strcpy( filename, "FHeader.dat" );
				// sub command loop
				do {
					printf( "\nSelect (1-2, 0)\n" );
					printf( " 1. Save File Header in the file named \"FHeader.dat\"\n" );
					printf( " 2. Show File Header \n" );
					printf( " 0. Exit\n>" );
					scanf( "%s", buf );
					wSubSel = atoi( buf );
					switch( wSubSel )
					{
						case 1:// Save
							bRet = SaveArrayCapability( pRefDat, kNkMAIDCapability_FileHeader, filename );
							break;
						case 2:// Show
							bRet = ShowArrayCapability( pRefDat, kNkMAIDCapability_FileHeader );
							break;
						default:
							wSubSel = 0;
					}
					if ( bRet == false )	return false;
				} while( wSubSel > 0 );
				break;
			case 7:// Acquire[3.19]
				bRet = IssueAcquire( pRefDat );
				// The item has been possibly removed.
				break;
			default:
				wSel = 0;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel > 0 && g_bFileRemoved == false );

// Close Image_Object
	bRet = RemoveChild( pRefItm, ulDatID );

	return bRet;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
BOOL ThumbnailCommandLoop( LPRefObj pRefItm, ULONG ulDatID )
{
	LPRefObj	pRefDat = NULL;
	char	buf[256];
	UWORD	wSel;
	BOOL	bRet = true;

	pRefDat = GetRefChildPtr_ID( pRefItm, ulDatID );
	if ( pRefDat == NULL ) {
		// Create Thumbnail object and RefSrc structure.
		if ( AddChild( pRefItm, ulDatID ) == true ) {
			printf("Thumbnail object is opened.\n");
		} else {
			printf("Thumbnail object can't be opened.\n");
			return false;
		}
		pRefDat = GetRefChildPtr_ID( pRefItm, ulDatID );
	}

	// command loop
	do {
		printf( "\nSelect (1-5, 0)\n" );
		printf( " 1. IsAlive                  2. Name                     3. StoredBytes\n" );
		printf( " 4. Pixels                   5. Acquire \n" );
		printf( " 0. Exit\n>" );
		scanf( "%s", buf );
		wSel = atoi( buf );

		switch( wSel )
		{
			case 1:// IsAlive[3.6]
				bRet = SetBoolCapability( pRefDat, kNkMAIDCapability_IsAlive );
				break;
			case 2:// Name[3.9]
				bRet = SetStringCapability( pRefDat, kNkMAIDCapability_Name );
				break;
			case 3:// StoredBytes[3.14]
				bRet = SetUnsignedCapability( pRefDat, kNkMAIDCapability_StoredBytes );
				break;
			case 4:// Pixels[3.40]
				// Get to know how many pixels there are in this image.
				bRet = SetSizeCapability( pRefDat, kNkMAIDCapability_Pixels );
				break;
			case 5:// Acquire[3.19]
				bRet = IssueAcquire( pRefDat );
				break;
			default:
				wSel = 0;
		}
		if ( bRet == false ) {
			printf( "An Error occured. Enter '0' to exit.\n>" );
			scanf( "%s", buf );
			bRet = true;
		}
	} while( wSel > 0 );

// Close Thumbnail_Object
	bRet = RemoveChild( pRefItm, ulDatID );

	return bRet;
}
//------------------------------------------------------------------------------------------------------------------------------------
//
