Nikon D40 Module SDK summary


Usage
 Control the camera.


Supported camera
 D40


Environment of operation
 [Macintosh]
    MacOS X 10.3.9(PowerPC)
    MacOS X 10.4.x(PowerPC)
    (D40 Module is executable on MacOS X 10.3.9, but "D40CtrlSample(Mac)" project 
     needs MacOS X 10.4.x to open project file, because this project is created 
     with Xcode 2.4.)
    * Please set Camera to PTP mode by SET UP menu (on camera body). If the camera 
      is set to Mass Storage, you can not control it by Macintosh. 

 [Windows]
    Windows 2000, XP
    * Please set Camera to PTP mode by SET UP menu (on camera body). If the camera 
      is set to Mass Storage, you can not control it by Windows. 


Contents
 [Macintosh]
    Documents
      MAID3(E).pdf : Basic interface specification
      MAID3D40(E).pdf : Extended interface specification used by D40 Module
      Usage of D40 Module(E).pdf : Notes for using D40 Module
      D40 Sample Guide(E).pdf : The usage of a sample program

   Binary Files
        D40 Module.bundle : D40 Module for Mac (PowerPC)
        libNkPTPDriver.dylib : PTP driver for Mac (PowerPC)
 
    Header Files
      Maid3.h : Basic header file of MAID interface
      Maid3d1.h : Extended header file for D40 Module
      NkTypes.h : Definitions of the types used in Maid3.h.

    Sample Program
      D40CtrlSample(Mac) : Sample program project for Xcode 2.4. (PowerPC)

 [Windows]
    Documents
      MAID3(E).pdf : Basic interface specification
      MAID3D40(E).pdf : Extended interface specification used by D40 Module
      Usage of D40 Module(E).pdf : Notes for using D40 Module
      D40 Sample Guide(E).pdf : The usage of a sample program

    Binary Files
      Win2000
        Inf files : �@Device drivers for PTP mode used by Windows 2000
        D40_Mod.md3 : D40 Module for Win
        NkdPTPDi.dll : Driver for PTP mode used by Windows 2000
      WinXP
        D40_Mod.md3 : D40 Module for Win
        NkdPTP.dll : Driver for PTP mode used by Windows XP

    Header Files
      Maid3.h : Basic header file of MAID interface
      Maid3d1.h : Extended header file for D40 Module
      NkTypes.h : Definitions of the types used in Maid3.h.

    Sample Program
      D40CtrlSample(Win) : Project for Microsoft Visual Studio .Net 2003
                           Project for Microsoft Visual C++ 6.0


Limitations
 This module cannot control two or more cameras.